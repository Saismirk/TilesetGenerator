﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using Random = UnityEngine.Random;
using Utils = TilesetGenerator.TileGenUtils;

namespace TilesetGenerator;

public class TilesetGenerator
{
    private const string FULL_PATH = "/TilesetGenerator/Resources/ExportTilemap/";
    
    public readonly List<Sprite> spriteList = new();

    private       Texture2D     _inTex;
    private       Texture2D     _inputTexFixed;
    public static int           ts;
    public static int           hs;
    private       Texture2D     _outTex;
    private       TilesetGeneratorEditorWindow _tileGenWindow;

    private Texture2D _finalTexture;

    private string _txtrPath;
    private string _ruleTilePath;

    private string _playerSetName;
    private string _inputFilename;

    private TilesetTextures _tilesetTextures;

    private static int Ts2 => ts * 2;
    private static int Ts3 => ts * 3;
    private static int Ts4 => ts * 4;
    private static int Ts5 => ts * 5;
    private static int Ts6 => ts * 6;
    private static int Ts7 => ts * 7;
    private static int Ts8 => ts * 8;

    public async UniTask CreateTilesetFromBaseTexture(Texture2D input, string filename, TilesetGeneratorEditorWindow tileGenWindow, CancellationToken ct = default)
    {
        _tileGenWindow = tileGenWindow;
        _inTex = input;
        _inputFilename = filename;
        ts = _inTex.width / 4;
        hs = ts / 2;
        _outTex = new(Ts8, Ts8);
        if (_tileGenWindow) _tileGenWindow.SetOutputTexture(_outTex);
        _outTex.filterMode = FilterMode.Point;
        Utils.CreateGrid(_outTex, ts);
        EditorUtility.DisplayProgressBar("Tileset Generation", "First Pass...", 0.1f);
        _inputTexFixed = new(_inTex.width, _inTex.height);
        _inTex.filterMode = FilterMode.Point;
        Utils.SimpleCopyPaste(_inputTexFixed, _inTex);
        Utils.EraseSquareSectionOfTexture(_inputTexFixed, new(Ts3, 0), ts, ts);

        _tilesetTextures = new();
        GC.Collect();
        await _tilesetTextures.GenerateSectionsFromInputTexture(_inTex, ts, ct);
        await Utils.CopyTexture(_outTex, _inputTexFixed, new(0, Ts4));
        await FirstPass(ct);
        await SecondPass(ct);
        await FinishUp(_inputFilename);
        await UniTask.Delay(100, cancellationToken: ct);
        CreateRuleTile();
    }

    private async UniTask FirstPass(CancellationToken ct)
    {
        Func<UniTask>[] pasteTasks =
        {
            () => Utils.CopyTextureSequential(_inTex, new(Ts3, 0), ts, Ts2, _outTex, new(_outTex.width + ts, _outTex.height + Ts6)),
            () => CopyTexture(_outTex, _tilesetTextures.island,       new(Ts3, Ts5)),
            () => CopyTexture(_outTex, _tilesetTextures.nwCorner,     new(Ts5, Ts7)),
            () => CopyTexture(_outTex, _tilesetTextures.neCorner,     new(Ts6, Ts7)),
            () => CopyTexture(_outTex, _tilesetTextures.swCorner,     new(Ts5, Ts6)),
            () => CopyTexture(_outTex, _tilesetTextures.seCorner,     new(Ts6, Ts6)),
            () => CopyTexture(_outTex, _tilesetTextures.nShore,       new(ts, Ts2)),
            () => CopyTexture(_outTex, _tilesetTextures.nShore,       new(0, ts)),
            () => CopyTexture(_outTex, _tilesetTextures.eShore,       new(Ts2, Ts2)),
            () => CopyTexture(_outTex, _tilesetTextures.eShore,       new(Ts4, Ts2)),
            () => CopyTexture(_outTex, _tilesetTextures.sShore,       new(Ts3, Ts2)),
            () => CopyTexture(_outTex, _tilesetTextures.sShore,       new(Ts5, Ts2)),
            () => CopyTexture(_outTex, _tilesetTextures.wShore,       new(0, Ts2)),
            () => CopyTexture(_outTex, _tilesetTextures.wShore,       new(Ts6, Ts2)),
            () => CopyTexture(_outTex, _tilesetTextures.nsBridge,     new(Ts5, Ts5)),
            () => CopyTexture(_outTex, _tilesetTextures.nsBridge,     new(ts, Ts4)),
            () => CopyTexture(_outTex, _tilesetTextures.nsBridge,     new(Ts3, Ts4)),
            () => CopyTexture(_outTex, _tilesetTextures.weBridge,     new(Ts6, Ts5)),
            () => CopyTexture(_outTex, _tilesetTextures.weBridge,     new(0, Ts4)),
            () => CopyTexture(_outTex, _tilesetTextures.weBridge,     new(Ts2, Ts4)),
            () => CopyTexture(_outTex, _tilesetTextures.intersection, new(Ts4, Ts5)),
            () => CopyTexture(_outTex, _tilesetTextures.intersection, new(Ts4, Ts4)),
            () => CopyTexture(_outTex, _tilesetTextures.intersection, new(Ts5, Ts4)),
            () => CopyTexture(_outTex, _tilesetTextures.intersection, new(Ts6, Ts4)),
            () => CopyTexture(_outTex, _tilesetTextures.intersection, new(0, Ts3)),
            () => CopyTexture(_outTex, _tilesetTextures.intersection, new(ts, Ts3)),
            () => CopyTexture(_outTex, _tilesetTextures.intersection, new(Ts2, Ts3)),
            () => CopyTexture(_outTex, _tilesetTextures.intersection, new(Ts3, Ts3)),
            () => CopyTexture(_outTex, _tilesetTextures.intersection, new(Ts4, Ts3)),
            () => CopyTexture(_outTex, _tilesetTextures.intersection, new(Ts5, Ts3)),
            () => CopyTexture(_outTex, _tilesetTextures.intersection, new(Ts6, Ts3)),
            () => CopyTexture(_outTex, _tilesetTextures.intersection, new(ts, ts)),
            () => CopyTexture(_outTex, _tilesetTextures.intersection, new(Ts2, ts)),
            () => CopyTexture(_outTex, _tilesetTextures.intersection, new(Ts3, ts)),
            () => CopyTexture(_outTex, _tilesetTextures.intersection, new(Ts4, ts)),
        };

        float progressStep = pasteTasks.Length > 0 ? 1f / pasteTasks.Length : 1;
        foreach ((Func<UniTask> value, int index) task in pasteTasks.Select((value, index) => (value, index))) {
            EditorUtility.DisplayProgressBar("Tileset Generation",
                                             $"First Pass - Copying Texture Sections (Step {task.index + 1}/{pasteTasks.Length})",
                                             0.1f + Mathf.Lerp(0, 1, task.index * progressStep));
            if (ct.IsCancellationRequested) break;
            await task.value.Invoke().AttachExternalCancellation(ct);
        }
    }

    private async UniTask SecondPass(CancellationToken ct = default)
    {
        Func<UniTask>[] pasteTasks =
        {
            () => CopyTexture(_outTex, _tilesetTextures.seMiniInvCorner, new(Ts5 + hs, Ts7)),
            () => CopyTexture(_outTex, _tilesetTextures.swMiniInvCorner, new(Ts6, Ts7)),
            () => CopyTexture(_outTex, _tilesetTextures.neMiniInvCorner, new(Ts5 + hs, Ts6 + hs)),
            () => CopyTexture(_outTex, _tilesetTextures.nwMiniInvCorner, new(Ts6, Ts6 + hs)),
            () => CopyTexture(_outTex, _tilesetTextures.nwMiniCorner,    new(0, Ts4 + hs)),
            () => CopyTexture(_outTex, _tilesetTextures.swMiniCorner,    new(0, Ts4)),
            () => CopyTexture(_outTex, _tilesetTextures.nwMiniCorner,    new(ts, Ts4 + hs)),
            () => CopyTexture(_outTex, _tilesetTextures.neMiniCorner,    new(ts + hs, Ts4 + hs)),
            () => CopyTexture(_outTex, _tilesetTextures.neMiniCorner,    new(Ts2 + hs, Ts4 + hs)),
            () => CopyTexture(_outTex, _tilesetTextures.seMiniCorner,    new(Ts2 + hs, Ts4)),
            () => CopyTexture(_outTex, _tilesetTextures.swMiniCorner,    new(Ts3, Ts4)),
            () => CopyTexture(_outTex, _tilesetTextures.seMiniCorner,    new(Ts3 + hs, Ts4)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts + hs, Ts2 + hs),  hs, hs), new(Ts4 + hs, Ts4 + hs)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts, Ts2),            hs, hs), new(Ts4, Ts4)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts, Ts2 + hs),       hs, hs), new(Ts5, Ts4 + hs)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts + hs, Ts2),       hs, hs), new(Ts5 + hs, Ts4)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts, Ts2),            hs, hs), new(Ts6, Ts4)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts + hs, Ts2 + hs),  hs, hs), new(Ts4 + hs, Ts3 + hs)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts + hs, Ts2),       hs, hs), new(Ts5 + hs, Ts3)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts, Ts2 + hs),       hs, hs), new(Ts6, Ts3 + hs)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts, ts),             hs, hs), new(0, Ts3)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts + hs, ts),        hs, hs), new(hs, Ts3)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(0, Ts2 + hs),        hs, hs), new(ts, Ts3 + hs)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(0, Ts2),             hs, hs), new(ts, Ts3)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts, Ts3 + hs),       hs, hs), new(Ts2, Ts3 + hs)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts + hs, Ts3 + hs),  hs, hs), new(Ts2 + hs, Ts3 + hs)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(Ts2 + hs, Ts2 + hs), hs, hs), new(Ts3 + hs, Ts3 + hs)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(Ts2 + hs, Ts2),      hs, hs), new(Ts3 + hs, Ts3)),
            () => CopyTexture(_outTex, _tilesetTextures.neMiniInvCorner, new(hs, Ts2 + hs)),
            () => CopyTexture(_outTex, _tilesetTextures.seMiniInvCorner, new(ts + hs, Ts2)),
            () => CopyTexture(_outTex, _tilesetTextures.swMiniInvCorner, new(Ts2, Ts2)),
            () => CopyTexture(_outTex, _tilesetTextures.nwMiniInvCorner, new(Ts3, Ts2 + hs)),
            () => CopyTexture(_outTex, _tilesetTextures.nwMiniInvCorner, new(Ts4, Ts2 + hs)),
            () => CopyTexture(_outTex, _tilesetTextures.neMiniInvCorner, new(Ts5 + hs, Ts2 + hs)),
            () => CopyTexture(_outTex, _tilesetTextures.seMiniInvCorner, new(Ts6 + hs, Ts2)),
            async () => await CopyTexture(_outTex, _tilesetTextures.swMiniInvCorner,                                   new(0, ts)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts, Ts2),           hs, hs), new(ts, ts)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts + hs, Ts2),      hs, hs), new(ts + hs, ts)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts, Ts2 + hs),      hs, hs), new(Ts2, ts + hs)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts, Ts2),           hs, hs), new(Ts2, ts)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts, Ts2 + hs),      hs, hs), new(Ts3, ts + hs)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts + hs, Ts2 + hs), hs, hs), new(Ts3 + hs, ts + hs)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts + hs, Ts2 + hs), hs, hs), new(Ts4 + hs, ts + hs)),
            async () => await CopyTexture(_outTex, await Utils.GetTextureCopy(_inTex, new(ts + hs, Ts2),      hs, hs), new(Ts4 + hs, ts)),
        };

        float progressStep = pasteTasks.Length > 0 ? 0.5f / pasteTasks.Length : 0.5f;
        foreach ((Func<UniTask> value, int index) task in pasteTasks.Select((value, index) => (value, index))) {
            if (ct.IsCancellationRequested) break;
            await task.value.Invoke().AttachExternalCancellation(ct);
            EditorUtility.DisplayProgressBar("Tileset Generation",
                                             $"Second Pass - Copying Texture Sections (Step {task.index + 1}/{pasteTasks.Length})",
                                             0.1f + Mathf.Lerp(0, 1, task.index * progressStep));
        }
    }

    private async UniTask FinishUp(string fileName = "")
    {
        int localT = (int)Time.time;
        int localI = Random.Range(100, 999);
        string t = localT.ToString();
        string i = localI.ToString();
        string name = Utils.GetSanitizedFileName(fileName, t);
        _playerSetName = name;
        
        _txtrPath = FULL_PATH + _playerSetName + Utils.FILE_TYPE;
        byte[] bytes = _outTex.EncodeToPNG();
        await File.WriteAllBytesAsync(Application.dataPath + FULL_PATH + _playerSetName + Utils.FILE_TYPE, bytes);
        AssetDatabase.ActiveRefreshImportMode = AssetDatabase.RefreshImportMode.InProcess;
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
        await UniTask.Delay(1000);
        _finalTexture = await Resources.LoadAsync<Texture2D>("ExportTilemap/" + _playerSetName) as Texture2D;
        if (!_finalTexture) {
            Debug.LogError("Failed to load the generated texture from Resources. Make sure the file was saved correctly.");
            return;
        }

        Utils.SetUpTextureSettings(ref _finalTexture);
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
        Utils.GenerateTileSpriteRects(ref _finalTexture);
        AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
        AssetDatabase.SaveAssets();
        EditorUtility.ClearProgressBar();
        EditorUtility.DisplayDialog("TileGen", $"Tileset generation complete!\n\nGenerated texture can be found at:\n\nAssets{_txtrPath}", "OK");
        Selection.activeObject = _finalTexture;
    }

    private void GetChildTiles()
    {
        Sprite[] sprites = Resources.LoadAll<Sprite>("ExportTilemap/" + _playerSetName);
        spriteList.Clear();
        foreach (var sprite in sprites) {
            spriteList.Add(sprite);
        }

        for (int i = 0; i < spriteList.Count; i++) {
            spriteList[i].name = "tile_" + i;
        }
    }

    private static async UniTask CopyTexture(Texture2D bottomTex, Texture2D topTex, Vector2 coord)
    {
        int dstX = (int)coord.x;
        int dstY = (int)coord.y;
        Graphics.CopyTexture(topTex, 0, 0, 0, 0, topTex.width, topTex.height,
                             bottomTex, 0, 0, dstX, dstY);
        bottomTex.Apply();
        await UniTask.Yield();
    }

    public void CreateRuleTile()
    {
        GetChildTiles();
        if (spriteList is not { Count: >= 46 }) {
            Debug.LogError("Sprite list does not contain enough sprites to create a Rule Tile. Expected at least 46 sprites, found " + spriteList.Count);
            return;
        }

        Debug.Log("Creating Rule tile.");
        _ruleTilePath = $"Assets/{nameof(TilesetGenerator)}/Resources/ExportTilemap/{_playerSetName}ruletile.asset";
        if (File.Exists(Application.dataPath + FULL_PATH + _playerSetName + "ruletile.asset")) {
            if (EditorUtility.DisplayDialog("TileGen", "A Rule Tile with this name already exists. Do you want to overwrite it?", "Yes", "No")) {
                File.Delete(Application.dataPath + FULL_PATH + _playerSetName + "ruletile.asset");
                AssetDatabase.Refresh();
            }
            else {
                return;
            }
        }
        
        RuleTile rTile = ScriptableObject.CreateInstance<RuleTile>();
        AssetDatabase.CreateAsset(rTile, _ruleTilePath);
        rTile.m_DefaultSprite = spriteList[0];
        rTile.m_DefaultSprite = spriteList[17];
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[33], Utils.R33));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[27], Utils.R27));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[34], Utils.R34));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[32], Utils.R32));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[0],  Utils.R0));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[2],  Utils.R02));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[16], Utils.R16));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[14], Utils.R14));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[1],  Utils.R01));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[43], Utils.R43));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[44], Utils.R44));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[45], Utils.R45));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[46], Utils.R46));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[3],  Utils.R03));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[4],  Utils.R04));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[5],  Utils.R05));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[6],  Utils.R06));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[7],  Utils.R07));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[8],  Utils.R08));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[9],  Utils.R09));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[10], Utils.R10));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[11], Utils.R11));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[12], Utils.R12));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[13], Utils.R13));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[15], Utils.R15));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[17], Utils.R17));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[18], Utils.R18));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[19], Utils.R19));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[20], Utils.R20));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[21], Utils.R21));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[23], Utils.R23));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[24], Utils.R24));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[22], Utils.R22));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[25], Utils.R25));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[26], Utils.R26));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[28], Utils.R28));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[29], Utils.R29));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[30], Utils.R30));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[31], Utils.R31));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[35], Utils.R35));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[36], Utils.R36));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[37], Utils.R37));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[38], Utils.R38));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[39], Utils.R39));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[40], Utils.R40));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[41], Utils.R41));
        rTile.m_TilingRules.Add(Utils.CreateTilingRule(spriteList[42], Utils.R42));

        EditorUtility.ClearProgressBar();
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        if (EditorUtility.DisplayDialog("TileGen", "Rule Tile created successfully!\nYou can find it at: " + _ruleTilePath, "OK")) {
            EditorUtility.SetDirty(rTile);
        }
    }
}