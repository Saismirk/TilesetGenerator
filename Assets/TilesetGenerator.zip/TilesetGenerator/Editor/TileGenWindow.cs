using System;
using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEditor;
using UnityEditor.Experimental;
using UnityEngine;

namespace TilesetGenerator
{
    public enum TileGenInputMode
    {
        FromSpriteSheet,
        FromSprites
    }

    public class TileGenWindow : EditorWindow
    {
        private const int              TEX_OBJ_SIZE   = 76;
        private       string           _inputFilename = string.Empty;
        private       Texture2D        _inputTexture;
        private       Texture2D        _convertedInputTexture;
        private       Texture2D        _outputTexture;
        private       TilesetGenerator _tilePacker;

        private Vector2 _scrollPosition;
        private string  _errorMessage      = string.Empty;
        private bool    _showError         = false;
        private bool    _validInputSprites = false;
        
        private Texture2D _cornersLayoutTexture;
        private Texture2D _invCornersLayoutTexture;

        private Sprite nwCornerSprite;
        private Sprite neCornerSprite;
        private Sprite swCornerSprite;
        private Sprite seCornerSprite;
        private Sprite nShoreSprite;
        private Sprite eShoreSprite;
        private Sprite sShoreSprite;
        private Sprite wShoreSprite;
        private Sprite nwInvCornerSprite;
        private Sprite neInvCornerSprite;
        private Sprite swInvCornerSprite;
        private Sprite seInvCornerSprite;
        private Sprite coreSprite;

        private bool _generatingTileset = false;

        private TileGenInputMode _inputMode = TileGenInputMode.FromSpriteSheet;

        private CancellationTokenSource _cancellationTokenSource = new();

        [MenuItem("Tools/Tileset Generator")]
        public static void ShowWindow() => GetWindow<TileGenWindow>("Tileset Generator");

        private void OnEnable()
        {
            _inputFilename = EditorPrefs.GetString("TileGenWindow.InputFilename", "GeneratedTileset");
            _tilePacker = new();
            _outputTexture = null;
            _convertedInputTexture = null;
            _validInputSprites = ValidateInputSprites();
            _cornersLayoutTexture = AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/TilesetGenerator/Editor/Textures/tileset_corner_layout.png");
            _invCornersLayoutTexture = AssetDatabase.LoadAssetAtPath<Texture2D>("Assets/TilesetGenerator/Editor/Textures/tileset_inv_corner_layout.png");
        }

        private void OnDisable()
        {
            EditorPrefs.SetString("TileGenWindow.InputFilename", _inputFilename);
        }

        private void OnGUI()
        {
            _scrollPosition = EditorGUILayout.BeginScrollView(_scrollPosition);

            EditorGUILayout.Space(10);
            EditorGUILayout.LabelField("TILESET GENERATOR", EditorStyles.centeredGreyMiniLabel);
            EditorGUILayout.Space(10);

            GUILayout.BeginVertical("Box");
            EditorGUILayout.LabelField("SETTINGS", EditorStyles.centeredGreyMiniLabel);
            _inputMode = (TileGenInputMode)EditorGUILayout.EnumPopup("Input Mode", _inputMode);
            _inputFilename = EditorGUILayout.TextField("Output Filename", _inputFilename);
            GUILayout.EndVertical();

            EditorGUILayout.Space(10);
            GUILayout.BeginVertical("Box");
            switch (_inputMode) {
                case TileGenInputMode.FromSpriteSheet:
                    DrawTextureInput();
                    DrawSpriteSheetTilesetGeneration();
                    break;
                case TileGenInputMode.FromSprites:
                    DrawSpriteInput();
                    DrawSpriteTilesetGeneration();
                    break;
            }


            GUILayout.EndVertical();

            if (_showError) {
                EditorGUILayout.Space(10);
                EditorGUILayout.HelpBox(_errorMessage, MessageType.Error);
            }

            EditorGUILayout.EndScrollView();
        }

        private void DrawTextureInput()
        {
            using var scope = new GUILayout.VerticalScope("Box");
            EditorGUILayout.LabelField("INPUT SPRITESHEET", EditorStyles.centeredGreyMiniLabel);
            using var indentScope = new EditorGUI.IndentLevelScope();
            EditorGUI.BeginChangeCheck();
            _inputTexture = (Texture2D)EditorGUILayout.ObjectField("Input Texture", _inputTexture, typeof(Texture2D), false);
            if (EditorGUI.EndChangeCheck() && _inputTexture) {
                ValidateInputTexture();
                _outputTexture = null;
            }

            if (!_inputTexture) {
                EditorGUILayout.HelpBox("Please select an input texture to generate the tileset from.", MessageType.Info);
                return;
            }

            EditorGUILayout.Space(10);
            var rect = GUILayoutUtility.GetRect(200, 200);
            EditorGUI.DrawTextureTransparent(rect, _inputTexture, ScaleMode.ScaleToFit, 0, 0);
            EditorGUILayout.LabelField("Input Tileset", EditorStyles.centeredGreyMiniLabel);
        }

        private void DrawSpriteInput()
        {
            using var scope = new GUILayout.VerticalScope("Box");
            EditorGUILayout.LabelField("INPUT SPRITES", EditorStyles.centeredGreyMiniLabel);
            using var indentScope = new EditorGUI.IndentLevelScope();
            
            float labelWidth = EditorGUIUtility.labelWidth;
            EditorGUIUtility.labelWidth = 0;
            EditorGUI.BeginChangeCheck();
            GUILayout.BeginVertical("Box");
            if (_cornersLayoutTexture) {
                var rect = GUILayoutUtility.GetRect(128, 128);
                GUI.DrawTexture(rect, _cornersLayoutTexture, ScaleMode.ScaleToFit);
            }
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            nwCornerSprite = (Sprite)EditorGUILayout.ObjectField(GUIContent.none, nwCornerSprite, typeof(Sprite), false, GUILayout.Width(TEX_OBJ_SIZE));
            nShoreSprite = (Sprite)EditorGUILayout.ObjectField(GUIContent.none,   nShoreSprite,   typeof(Sprite), false, GUILayout.Width(TEX_OBJ_SIZE));
            neCornerSprite = (Sprite)EditorGUILayout.ObjectField(GUIContent.none, neCornerSprite, typeof(Sprite), false, GUILayout.Width(TEX_OBJ_SIZE));
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            wShoreSprite = (Sprite)EditorGUILayout.ObjectField(GUIContent.none, wShoreSprite, typeof(Sprite), false, GUILayout.Width(TEX_OBJ_SIZE));
            coreSprite = (Sprite)EditorGUILayout.ObjectField(GUIContent.none,   coreSprite,   typeof(Sprite), false, GUILayout.Width(TEX_OBJ_SIZE));
            eShoreSprite = (Sprite)EditorGUILayout.ObjectField(GUIContent.none, eShoreSprite, typeof(Sprite), false, GUILayout.Width(TEX_OBJ_SIZE));
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            swCornerSprite = (Sprite)EditorGUILayout.ObjectField(GUIContent.none, swCornerSprite, typeof(Sprite), false, GUILayout.Width(TEX_OBJ_SIZE));
            sShoreSprite = (Sprite)EditorGUILayout.ObjectField(GUIContent.none,   sShoreSprite,   typeof(Sprite), false, GUILayout.Width(TEX_OBJ_SIZE));
            seCornerSprite = (Sprite)EditorGUILayout.ObjectField(GUIContent.none, seCornerSprite, typeof(Sprite), false, GUILayout.Width(TEX_OBJ_SIZE));
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            GUILayout.EndVertical();

            GUILayout.BeginVertical("Box");
            if (_invCornersLayoutTexture) {
                var rect = GUILayoutUtility.GetRect(64, 64);
                GUI.DrawTexture(rect, _invCornersLayoutTexture, ScaleMode.ScaleToFit);
            }
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            nwInvCornerSprite = (Sprite)EditorGUILayout.ObjectField(GUIContent.none, nwInvCornerSprite, typeof(Sprite), false, GUILayout.Width(TEX_OBJ_SIZE));
            neInvCornerSprite = (Sprite)EditorGUILayout.ObjectField(GUIContent.none, neInvCornerSprite, typeof(Sprite), false, GUILayout.Width(TEX_OBJ_SIZE));
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            swInvCornerSprite = (Sprite)EditorGUILayout.ObjectField(GUIContent.none, swInvCornerSprite, typeof(Sprite), false, GUILayout.Width(TEX_OBJ_SIZE));
            seInvCornerSprite = (Sprite)EditorGUILayout.ObjectField(GUIContent.none, seInvCornerSprite, typeof(Sprite), false, GUILayout.Width(TEX_OBJ_SIZE));
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            GUILayout.EndVertical();
            
            EditorGUIUtility.labelWidth = labelWidth;
            if (EditorGUI.EndChangeCheck()) {
                _validInputSprites = ValidateInputSprites();
            }

            if (!_validInputSprites) {
                EditorGUILayout.HelpBox("Please assign all tileset sprites.", MessageType.Info);
            }
        }

        private void DrawSpriteSheetTilesetGeneration()
        {
            using var scope = new GUILayout.VerticalScope("Box");
            if (!_inputTexture) return;
            EditorGUILayout.LabelField("TILESET GENERATION", EditorStyles.centeredGreyMiniLabel);
            if (_outputTexture) {
                EditorGUILayout.Space(10);
                var rect = GUILayoutUtility.GetRect(200, 200);
                EditorGUI.DrawTextureTransparent(rect, _outputTexture, ScaleMode.ScaleToFit, 0, 0);
                EditorGUILayout.LabelField("Generated Tileset", EditorStyles.centeredGreyMiniLabel);
            }

            EditorGUILayout.Space(10);
            if (!_generatingTileset) DisplayButton(GenerateTileset, "Generate Tileset");
            else DisplayButton(CancelGeneration, "Cancel Generation");
            EditorGUILayout.Space(10);
        }

        private void DrawSpriteTilesetGeneration()
        {
            using var scope = new GUILayout.VerticalScope("Box");
            if (!_validInputSprites) return;
            EditorGUILayout.LabelField("TILESET GENERATION", EditorStyles.centeredGreyMiniLabel);

            if (_convertedInputTexture) {
                EditorGUILayout.Space(10);
                var rect = GUILayoutUtility.GetRect(200, 200);
                EditorGUI.DrawTextureTransparent(rect, _convertedInputTexture, ScaleMode.ScaleToFit, 0, 0);
                EditorGUILayout.LabelField("Generated Input", EditorStyles.centeredGreyMiniLabel);
            }

            if (_outputTexture) {
                EditorGUILayout.Space(10);
                var rect = GUILayoutUtility.GetRect(200, 200);
                EditorGUI.DrawTextureTransparent(rect, _outputTexture, ScaleMode.ScaleToFit, 0, 0);
                EditorGUILayout.LabelField("Generated Tileset", EditorStyles.centeredGreyMiniLabel);
            }

            EditorGUILayout.Space(10);
            if (!_generatingTileset) DisplayButton(GenerateTileset, "Generate Tileset");
            else DisplayButton(CancelGeneration, "Cancel Generation");
            EditorGUILayout.Space(10);
        }

        private void ValidateInputTexture()
        {
            _showError = false;
            if (CheckIfSquare(_inputTexture)) return;
            _showError = true;
            _errorMessage =
                $"Your image is not a square. The width should be the same as the height. " +
                $"Current width is {_inputTexture.width} and current height is {_inputTexture.height}";
            _inputTexture = null;
        }

        private bool ValidateInputSprites() =>
            nwCornerSprite &&
            neCornerSprite &&
            swCornerSprite &&
            seCornerSprite &&
            nShoreSprite &&
            eShoreSprite &&
            sShoreSprite &&
            wShoreSprite &&
            nwInvCornerSprite &&
            neInvCornerSprite &&
            swInvCornerSprite &&
            seInvCornerSprite &&
            coreSprite;

        private static bool CheckIfSquare(Texture2D t2d) => t2d.width == t2d.height;
        private        void GenerateTileset()            => GenerateTilesetAsync().Forget();
        private void CancelGeneration()
        {
            _cancellationTokenSource?.Cancel();
            _generatingTileset = false;
        }

        private async UniTaskVoid GenerateTilesetAsync()
        {
            if (_tilePacker == null) {
                Debug.LogError("TilePacker is null!");
                return;
            }

            _cancellationTokenSource?.Cancel();
            _cancellationTokenSource = new();
            try {
                _generatingTileset = true;
                switch (_inputMode) {
                    case TileGenInputMode.FromSpriteSheet:
                        if (!_inputTexture) {
                            Debug.LogError("InputTexture is null!");
                            return;
                        }
                        
                        // await _tilePacker.CreateTilesetFromBaseTexture(_inputTexture, _inputFilename, this, _cancellationTokenSource.Token);
                        break;
                    case TileGenInputMode.FromSprites:
                        await GenerateInputTextureAsync();
                        if (!_convertedInputTexture) {
                            Debug.LogError("ConvertedInputTexture is null!");
                            return;
                        }

                        // await _tilePacker.CreateTilesetFromBaseTexture(_convertedInputTexture, _inputFilename, this, _cancellationTokenSource.Token);
                        break;
                }
            }
            catch (Exception e) {
                Debug.LogError($"Error during tileset generation: {e.Message}");
                EditorUtility.DisplayDialog("Tileset Generation Error", $"An error occurred during tileset generation:\n{e.Message}", "OK");
            }
            finally {
                EditorUtility.ClearProgressBar();
                _generatingTileset = false;
            }
        }

        private async UniTask GenerateInputTextureAsync()
        {
            TilesetTextures tilesetTextures = new();
            _convertedInputTexture = await tilesetTextures.GetInputTextureFromSprites(nwCornerSprite,
                                                                                      neCornerSprite,
                                                                                      swCornerSprite,
                                                                                      seCornerSprite,
                                                                                      nShoreSprite,
                                                                                      eShoreSprite,
                                                                                      sShoreSprite,
                                                                                      wShoreSprite,
                                                                                      nwInvCornerSprite,
                                                                                      neInvCornerSprite,
                                                                                      swInvCornerSprite,
                                                                                      seInvCornerSprite,
                                                                                      coreSprite,
                                                                                      (int)neCornerSprite.rect.width);
        }

        private void ResetAll()
        {
            _inputTexture = null;
            _outputTexture = null;
            _cancellationTokenSource?.Cancel();
        }

        public void SetOutputTexture(Texture2D         outputTex) => _outputTexture = outputTex;

        private static void DisplayButton(Action onClick, string label)
        {
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button(label, GUILayout.MaxWidth(200))) {
                onClick?.Invoke();
            }

            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
        }
    }
}