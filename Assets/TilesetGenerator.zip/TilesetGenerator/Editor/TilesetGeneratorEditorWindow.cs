using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using Cysharp.Threading.Tasks;
using TilesetGenerator.Controls;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;
using Image = UnityEngine.UIElements.Image;

namespace TilesetGenerator
{
    [SuppressMessage("ReSharper", "HeapView.ClosureAllocation")]
    public class TilesetGeneratorEditorWindow : EditorWindow
    {
        private const string USS_PATH = "Assets/TilesetGenerator/Editor/TilesetGeneratorEditorWindow.uss";

        private const int TEX_OBJ_SIZE = 76;

        [SerializeField] private string _inputFilename = string.Empty;

        private Texture2D        _inputTexture;
        private Texture2D        _convertedInputTexture;
        private Texture2D        _outputTexture;
        private TilesetGenerator _tilePacker;

        private Vector2 _scrollPosition;
        private bool    _validInputSprites = false;

        private Texture2D _cornersLayoutTexture;
        private Texture2D _invCornersLayoutTexture;

        [SerializeField] private Sprite _nwCornerSprite;
        [SerializeField] private Sprite _neCornerSprite;
        [SerializeField] private Sprite _swCornerSprite;
        [SerializeField] private Sprite _seCornerSprite;
        [SerializeField] private Sprite _nShoreSprite;
        [SerializeField] private Sprite _eShoreSprite;
        [SerializeField] private Sprite _sShoreSprite;
        [SerializeField] private Sprite _wShoreSprite;
        [SerializeField] private Sprite _nwInvCornerSprite;
        [SerializeField] private Sprite _neInvCornerSprite;
        [SerializeField] private Sprite _swInvCornerSprite;
        [SerializeField] private Sprite _seInvCornerSprite;
        [SerializeField] private Sprite _coreSprite;

        private bool _generatingTileset = false;

        private Label _spriteStatusLabel;
        private Label _spritesheetStatusLabel;

        private Button _generateFromSpritesheetButton;
        private Button _generateFromSpritesButton;
        
        private Image _outputTexturePreviewImage;

        private CancellationTokenSource _cancellationTokenSource = new();

        [SerializeField] private VisualTreeAsset MVisualTreeAsset;

        private void OnEnable()
        {
            MVisualTreeAsset = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>("Assets/TilesetGenerator/Editor/TilesetGeneratorEditorWindow.uxml");
        }

        [MenuItem("Window/UI Toolkit/TilesetGeneratorEditorWindow")]
        public static void ShowExample()
        {
            TilesetGeneratorEditorWindow wnd = GetWindow<TilesetGeneratorEditorWindow>();
            wnd.titleContent = new("Tileset Generator");
        }

        public void CreateGUI()
        {
            VisualElement root = rootVisualElement;
            VisualElement labelFromUxml = MVisualTreeAsset?.CloneTree();
            root.Add(labelFromUxml);
            root.Bind(new(this));
            _spritesheetStatusLabel = root.Q<Label>("generation-info-spritesheet");
            _spriteStatusLabel = root.Q<Label>("generation-info-sprites");
            root.Query<TileField>().ForEach(tile => {
                string[] nameParts = tile.name.Split('-');
                if (nameParts.Length < 2) return;
                tile.SetSprite(GetSpriteByName(tile.name));
                var highlightElement = root.Q<VisualElement>(string.Join("-", nameParts[..2]) + "-highlight");
                if (highlightElement == null) return;
                tile.RegisterCallback<PointerEnterEvent, VisualElement>((_, vs) => vs.style.opacity = 1, highlightElement);
                tile.RegisterCallback<PointerLeaveEvent, VisualElement>((_, vs) => vs.style.opacity = 0, highlightElement);
                tile.OnSpriteChanged += sprite => {
                    Debug.Log($"Sprite changed for {tile.name}");
                    SetSpriteByName(tile.name, sprite);
                    UpdateSpritesStatus();
                };
            });

            _outputTexturePreviewImage = root.Q<Image>("output-image");
            if (_outputTexturePreviewImage != null) _outputTexturePreviewImage.image = _outputTexture;
            root.Q<Button>("generate-tileset-spritesheet-button").clicked += () => {
                if (_generatingTileset) return;
                GenerateTilesetFromSpritesheetAsync().Forget();
            };

            _generateFromSpritesButton = root.Q<Button>("generate-tileset-sprites-button");
            if (_generateFromSpritesButton != null) {
                _generateFromSpritesButton.clicked += () => {
                    if (_generatingTileset) return;
                    GenerateTilesetFromSpritesAsync().Forget();
                };
            }

            UpdateSpritesStatus();
        }

        private void UpdateSpritesStatus()
        {
            _validInputSprites = ValidateInputSprites();
            _generateFromSpritesButton?.SetEnabled(_validInputSprites);
            if (_spriteStatusLabel == null) return;
            _spriteStatusLabel.text = _validInputSprites
                                          ? "All required sprites are assigned."
                                          : "Please assign all required sprites.";
        }

        private async UniTask GenerateInputTextureAsync()
        {
            TilesetTextures tilesetTextures = new();
            _convertedInputTexture = await tilesetTextures.GetInputTextureFromSprites(_nwCornerSprite,
                                                                                      _neCornerSprite,
                                                                                      _swCornerSprite,
                                                                                      _seCornerSprite,
                                                                                      _nShoreSprite,
                                                                                      _eShoreSprite,
                                                                                      _sShoreSprite,
                                                                                      _wShoreSprite,
                                                                                      _nwInvCornerSprite,
                                                                                      _neInvCornerSprite,
                                                                                      _swInvCornerSprite,
                                                                                      _seInvCornerSprite,
                                                                                      _coreSprite,
                                                                                      (int)_neCornerSprite.rect.width);
        }

        private void SetSpriteByName(string fieldName, Sprite sprite)
        {
            switch (fieldName) {
                case "nw-corner-tile":     _nwCornerSprite = sprite; break;
                case "ne-corner-tile":     _neCornerSprite = sprite; break;
                case "sw-corner-tile":     _swCornerSprite = sprite; break;
                case "se-corner-tile":     _seCornerSprite = sprite; break;
                case "n-corner-tile":      _nShoreSprite = sprite; break;
                case "e-corner-tile":      _eShoreSprite = sprite; break;
                case "s-corner-tile":      _sShoreSprite = sprite; break;
                case "w-corner-tile":      _wShoreSprite = sprite; break;
                case "nw-inv-corner-tile": _nwInvCornerSprite = sprite; break;
                case "ne-inv-corner-tile": _neInvCornerSprite = sprite; break;
                case "sw-inv-corner-tile": _swInvCornerSprite = sprite; break;
                case "se-inv-corner-tile": _seInvCornerSprite = sprite; break;
                case "core-corner-tile":   _coreSprite = sprite; break;
                default: Debug.LogWarning($"Unknown sprite field name: {fieldName}"); break;
            }
        }
        
        private Sprite GetSpriteByName(string fieldName) =>
            fieldName switch
            {
                "nw-corner-tile"     => _nwCornerSprite,
                "ne-corner-tile"     => _neCornerSprite,
                "sw-corner-tile"     => _swCornerSprite,
                "se-corner-tile"     => _seCornerSprite,
                "n-corner-tile"      => _nShoreSprite,
                "e-corner-tile"      => _eShoreSprite,
                "s-corner-tile"      => _sShoreSprite,
                "w-corner-tile"      => _wShoreSprite,
                "nw-inv-corner-tile" => _nwInvCornerSprite,
                "ne-inv-corner-tile" => _neInvCornerSprite,
                "sw-inv-corner-tile" => _swInvCornerSprite,
                "se-inv-corner-tile" => _seInvCornerSprite,
                "core-corner-tile"   => _coreSprite,
                _                    => null,
            };

        public void SetOutputTexture(Texture2D outputTex) => _outputTexture = outputTex;

        private async UniTaskVoid GenerateTilesetFromSpritesAsync()
        {
            _tilePacker ??= new();
            if (_outputTexturePreviewImage != null) _outputTexturePreviewImage.image = _outputTexture;
            _cancellationTokenSource?.Cancel();
            _cancellationTokenSource = new();
            try {
                _generatingTileset = true;

                await GenerateInputTextureAsync();
                if (!_convertedInputTexture) {
                    Debug.LogError("ConvertedInputTexture is null!");
                    return;
                }

                await _tilePacker.CreateTilesetFromBaseTexture(_convertedInputTexture, _inputFilename, this, _cancellationTokenSource.Token);
            }
            catch (Exception e) {
                Debug.LogError($"Error during tileset generation: {e.Message}");
                EditorUtility.DisplayDialog("Tileset Generation Error", $"An error occurred during tileset generation:\n{e.Message}", "OK");
            }
            finally {
                EditorUtility.ClearProgressBar();
                _generatingTileset = false;
            }
        }

        private async UniTaskVoid GenerateTilesetFromSpritesheetAsync()
        {
            _tilePacker ??= new();
            _cancellationTokenSource?.Cancel();
            _cancellationTokenSource = new();
            try {
                _generatingTileset = true;

                if (!_inputTexture) {
                    Debug.LogError("InputTexture is null!");
                    return;
                }

                await _tilePacker.CreateTilesetFromBaseTexture(_inputTexture, _inputFilename, this, _cancellationTokenSource.Token);
            }
            catch (Exception e) {
                Debug.LogError($"Error during tileset generation: {e.Message}");
                EditorUtility.DisplayDialog("Tileset Generation Error", $"An error occurred during tileset generation:\n{e.Message}", "OK");
            }
            finally {
                EditorUtility.ClearProgressBar();
                _generatingTileset = false;
            }
        }

        private bool ValidateInputSprites() =>
            _nwCornerSprite &&
            _neCornerSprite &&
            _swCornerSprite &&
            _seCornerSprite &&
            _nShoreSprite &&
            _eShoreSprite &&
            _sShoreSprite &&
            _wShoreSprite &&
            _nwInvCornerSprite &&
            _neInvCornerSprite &&
            _swInvCornerSprite &&
            _seInvCornerSprite &&
            _coreSprite;
    }
}