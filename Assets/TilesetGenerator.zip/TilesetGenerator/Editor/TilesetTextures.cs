using System.Threading;
using Cysharp.Threading.Tasks;
using UnityEditor;
using UnityEngine;
using Utils = TilesetGenerator.TileGenUtils;

namespace TilesetGenerator;

public class TilesetTextures
{
    public Texture2D nwMiniCorner;
    public Texture2D neMiniCorner;
    public Texture2D swMiniCorner;
    public Texture2D seMiniCorner;
    public Texture2D nwMiniInvCorner;
    public Texture2D neMiniInvCorner;
    public Texture2D swMiniInvCorner;
    public Texture2D seMiniInvCorner;
    public Texture2D nwCorner;
    public Texture2D neCorner;
    public Texture2D swCorner;
    public Texture2D seCorner;
    public Texture2D nwInvCorner;
    public Texture2D neInvCorner;
    public Texture2D swInvCorner;
    public Texture2D seInvCorner;
    public Texture2D nShore;
    public Texture2D eShore;
    public Texture2D sShore;
    public Texture2D wShore;
    public Texture2D island;
    public Texture2D intersection;
    public Texture2D nsBridge;
    public Texture2D weBridge;
    
    
    public async UniTask<Texture2D> GetInputTextureFromSprites(Sprite nwCornerSprite, Sprite neCornerSprite, Sprite swCornerSprite, Sprite seCornerSprite,
                                                Sprite nShoreSprite, Sprite eShoreSprite, Sprite sShoreSprite, Sprite wShoreSprite,
                                                Sprite nwInvCornerSprite, Sprite neInvCornerSprite, Sprite swInvCornerSprite, Sprite seInvCornerSprite,
                                                Sprite coreSprite,
                                                int tileSize)
    {
        int ts = tileSize;
        Texture2D outputTex = new(ts * 4, ts * 4)
                              {
                                  filterMode = FilterMode.Point
                              };
        await Utils.CopyTexture(outputTex, nwCornerSprite, new(0, outputTex.height - ts));
        await Utils.CopyTexture(outputTex, neCornerSprite, new(outputTex.width - ts * 2, outputTex.height - ts));
        await Utils.CopyTexture(outputTex, swCornerSprite, new(0, ts));
        await Utils.CopyTexture(outputTex, seCornerSprite, new(ts * 2, ts));
        await Utils.CopyTexture(outputTex, nShoreSprite, new(ts, ts * 3));
        await Utils.CopyTexture(outputTex, eShoreSprite, new(ts * 2, ts * 2));
        await Utils.CopyTexture(outputTex, sShoreSprite, new(ts, ts));
        await Utils.CopyTexture(outputTex, wShoreSprite, new(0, ts * 2));
        await Utils.CopyTexture(outputTex, nwInvCornerSprite, new(outputTex.width - ts, outputTex.height - ts));
        await Utils.CopyTexture(outputTex, swInvCornerSprite, new(outputTex.width - ts, outputTex.height - ts * 2));
        await Utils.CopyTexture(outputTex, neInvCornerSprite, new(outputTex.width - ts, outputTex.height - ts * 3));
        await Utils.CopyTexture(outputTex, seInvCornerSprite, new(outputTex.width - ts, outputTex.height - ts * 4));
        await Utils.CopyTexture(outputTex, coreSprite, new(ts, ts * 2));

        outputTex.Apply();
        return outputTex;
    }

    public async UniTask GenerateSectionsFromInputTexture(Texture2D inputTex, int tileSize, CancellationToken ct = default)
    {
        int ts = tileSize;
        int hs = ts / 2;
        EditorUtility.DisplayProgressBar("Tileset Generation", "Extracting Texture Sections...", 0.2f);
        nwMiniCorner = await Utils.GetTextureCopy(inputTex, new(0, ts * 3 + hs),           hs, hs);
        neMiniCorner = await Utils.GetTextureCopy(inputTex, new(ts * 2 + hs, ts * 3 + hs), hs, hs);
        swMiniCorner = await Utils.GetTextureCopy(inputTex, new(0, ts),                    hs, hs);
        seMiniCorner = await Utils.GetTextureCopy(inputTex, new(ts * 2 + hs, ts),          hs, hs);
        EditorUtility.DisplayProgressBar("Tileset Generation", "Extracting Texture Sections...", 0.3f);
        nwMiniInvCorner = await Utils.GetTextureCopy(inputTex, new(ts * 3, hs),               hs, hs);
        neMiniInvCorner = await Utils.GetTextureCopy(inputTex, new(ts * 3 + hs, ts * 2 + hs), hs, hs);
        swMiniInvCorner = await Utils.GetTextureCopy(inputTex, new(ts * 3, ts),               hs, hs);
        seMiniInvCorner = await Utils.GetTextureCopy(inputTex, new(ts * 3 + hs, ts * 3),      hs, hs);
        EditorUtility.DisplayProgressBar("Tileset Generation", "Extracting Texture Sections...", 0.4f);
        nwCorner = await Utils.GetTextureCopy(inputTex, new(0, inputTex.height - ts),                       ts, ts);
        neCorner = await Utils.GetTextureCopy(inputTex, new(inputTex.width - ts * 2, inputTex.height - ts), ts, ts);
        swCorner = await Utils.GetTextureCopy(inputTex, new(0, ts),                                         ts, ts);
        seCorner = await Utils.GetTextureCopy(inputTex, new(ts * 2, ts),                                    ts, ts);
        EditorUtility.DisplayProgressBar("Tileset Generation", "Extracting Texture Sections...", 0.5f);
        nwInvCorner = await Utils.GetTextureCopy(inputTex, new(inputTex.width - ts, inputTex.height - ts),     ts, ts);
        neInvCorner = await Utils.GetTextureCopy(inputTex, new(inputTex.width - ts, inputTex.height - ts * 2), ts, ts);
        swInvCorner = await Utils.GetTextureCopy(inputTex, new(inputTex.width - ts, inputTex.height - ts * 3), ts, ts);
        seInvCorner = await Utils.GetTextureCopy(inputTex, new(inputTex.width - ts, inputTex.height - ts * 4), ts, ts);
        EditorUtility.DisplayProgressBar("Tileset Generation", "Extracting Texture Sections...", 0.6f);
        nShore = await Utils.GetTextureCopy(inputTex, new(ts, ts * 3),     ts, ts);
        eShore = await Utils.GetTextureCopy(inputTex, new(ts * 2, ts * 2), ts, ts);
        sShore = await Utils.GetTextureCopy(inputTex, new(ts, ts),         ts, ts);
        wShore = await Utils.GetTextureCopy(inputTex, new(0, ts * 2),      ts, ts);
        
        island = new(ts, ts)
                  {
                      filterMode = FilterMode.Point
                  };
        EditorUtility.DisplayProgressBar("Tileset Generation", "Extracting Texture Sections...", 0.7f);
        await Utils.CopyTexture(island, nwMiniCorner, new(0, hs));
        await Utils.CopyTexture(island, neMiniCorner, new(hs, hs));
        await Utils.CopyTexture(island, swMiniCorner, new(0, 0));
        await Utils.CopyTexture(island, seMiniCorner, new(hs, 0));
        intersection = new(ts, ts)
                        {
                            filterMode = FilterMode.Point
                        };
        EditorUtility.DisplayProgressBar("Tileset Generation", "Extracting Texture Sections...", 0.8f);
        await Utils.CopyTexture(intersection, nwMiniInvCorner, new(0, hs));
        await Utils.CopyTexture(intersection, neMiniInvCorner, new(hs, hs));
        await Utils.CopyTexture(intersection, swMiniInvCorner, new(0, 0));
        await Utils.CopyTexture(intersection, seMiniInvCorner, new(hs, 0));
        nsBridge = new(ts, ts);
        intersection.filterMode = FilterMode.Point;
        EditorUtility.DisplayProgressBar("Tileset Generation", "Extracting Texture Sections...", 0.9f);
        await Utils.CopyTexture(nsBridge, await Utils.GetTextureCopy(wShore, new(0, 0),   hs, hs), new(0, 0));
        await Utils.CopyTexture(nsBridge, await Utils.GetTextureCopy(eShore, new(hs, 0),  hs, hs), new(hs, 0));
        await Utils.CopyTexture(nsBridge, await Utils.GetTextureCopy(wShore, new(0, hs),  hs, hs), new(0, hs));
        await Utils.CopyTexture(nsBridge, await Utils.GetTextureCopy(eShore, new(hs, hs), hs, hs), new(hs, hs));
        weBridge = new(ts, ts);
        intersection.filterMode = FilterMode.Point;
        EditorUtility.DisplayProgressBar("Tileset Generation", "Extracting Texture Sections...", 1f);
        await Utils.CopyTexture(weBridge, await Utils.GetTextureCopy(nShore, new(hs, hs), hs, hs), new(hs, hs));
        await Utils.CopyTexture(weBridge, await Utils.GetTextureCopy(sShore, new(hs, 0),  hs, hs), new(hs, 0));
        await Utils.CopyTexture(weBridge, await Utils.GetTextureCopy(nShore, new(0, hs),  hs, hs), new(0, hs));
        await Utils.CopyTexture(weBridge, await Utils.GetTextureCopy(sShore, new(0, 0),   hs, hs), new(0, 0));
    }
}