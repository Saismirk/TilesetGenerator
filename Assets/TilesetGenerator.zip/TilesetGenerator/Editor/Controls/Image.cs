using UnityEngine.UIElements;
namespace TilesetGenerator.Controls
{
    [UxmlElement]
    public partial class Image : UnityEngine.UIElements.Image
    {
    }
}